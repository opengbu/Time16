﻿Partial Class TimetableDataSet
End Class

Namespace TimetableDataSetTableAdapters
    
    Partial Class CSF_View_with_LoadTableAdapter

    End Class

    Partial Public Class SubjectTableAdapter
    End Class
End Namespace
