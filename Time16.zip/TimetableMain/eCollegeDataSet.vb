﻿Partial Class eCollegeDataSet
    Partial Public Class SectionDataTable
    End Class

    Partial Class adCourseStructureDataTable



    End Class

    Partial Class V_TimeTable1DataTable

        'Private Sub V_TimeTable1DataTable_ColumnChanging(ByVal sender As System.Object, ByVal e As System.Data.DataColumnChangeEventArgs) Handles Me.ColumnChanging
        '    If (e.Column.ColumnName = Me.TimeTableIdColumn.ColumnName) Then
        '        'Add user code here
        '    End If

        'End Sub

    End Class

End Class

Namespace eCollegeDataSetTableAdapters
    
    Partial Class V_TimeTableTableAdapter

    End Class

    Partial Public Class M_SectionTableAdapter
    End Class
End Namespace
