﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.InsertToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.DeleteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CopyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PasteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CopyToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.PasteToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SwapToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.DeleteToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.QuickInsertToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TextBox77 = New System.Windows.Forms.TextBox()
        Me.TextBox76 = New System.Windows.Forms.TextBox()
        Me.TextBox75 = New System.Windows.Forms.TextBox()
        Me.TextBox74 = New System.Windows.Forms.TextBox()
        Me.TextBox73 = New System.Windows.Forms.TextBox()
        Me.TextBox72 = New System.Windows.Forms.TextBox()
        Me.TextBox71 = New System.Windows.Forms.TextBox()
        Me.TextBox70 = New System.Windows.Forms.TextBox()
        Me.TextBox69 = New System.Windows.Forms.TextBox()
        Me.TextBox68 = New System.Windows.Forms.TextBox()
        Me.TextBox67 = New System.Windows.Forms.TextBox()
        Me.TextBox66 = New System.Windows.Forms.TextBox()
        Me.TextBox65 = New System.Windows.Forms.TextBox()
        Me.TextBox64 = New System.Windows.Forms.TextBox()
        Me.TextBox57 = New System.Windows.Forms.TextBox()
        Me.TextBox36 = New System.Windows.Forms.TextBox()
        Me.TextBox33 = New System.Windows.Forms.TextBox()
        Me.TextBox34 = New System.Windows.Forms.TextBox()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        Me.TextBox35 = New System.Windows.Forms.TextBox()
        Me.TextBox37 = New System.Windows.Forms.TextBox()
        Me.TextBox38 = New System.Windows.Forms.TextBox()
        Me.TextBox39 = New System.Windows.Forms.TextBox()
        Me.TextBox40 = New System.Windows.Forms.TextBox()
        Me.TextBox25 = New System.Windows.Forms.TextBox()
        Me.TextBox26 = New System.Windows.Forms.TextBox()
        Me.TextBox28 = New System.Windows.Forms.TextBox()
        Me.TextBox29 = New System.Windows.Forms.TextBox()
        Me.TextBox30 = New System.Windows.Forms.TextBox()
        Me.TextBox31 = New System.Windows.Forms.TextBox()
        Me.TextBox32 = New System.Windows.Forms.TextBox()
        Me.TextBox17 = New System.Windows.Forms.TextBox()
        Me.TextBox18 = New System.Windows.Forms.TextBox()
        Me.TextBox19 = New System.Windows.Forms.TextBox()
        Me.TextBox20 = New System.Windows.Forms.TextBox()
        Me.TextBox21 = New System.Windows.Forms.TextBox()
        Me.TextBox22 = New System.Windows.Forms.TextBox()
        Me.TextBox23 = New System.Windows.Forms.TextBox()
        Me.TextBox24 = New System.Windows.Forms.TextBox()
        Me.TextBox9 = New System.Windows.Forms.TextBox()
        Me.TextBox10 = New System.Windows.Forms.TextBox()
        Me.TextBox11 = New System.Windows.Forms.TextBox()
        Me.TextBox12 = New System.Windows.Forms.TextBox()
        Me.TextBox13 = New System.Windows.Forms.TextBox()
        Me.TextBox14 = New System.Windows.Forms.TextBox()
        Me.TextBox15 = New System.Windows.Forms.TextBox()
        Me.TextBox16 = New System.Windows.Forms.TextBox()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox27 = New System.Windows.Forms.TextBox()
        Me.TextBox47 = New System.Windows.Forms.TextBox()
        Me.TextBox48 = New System.Windows.Forms.TextBox()
        Me.TextBox45 = New System.Windows.Forms.TextBox()
        Me.TextBox44 = New System.Windows.Forms.TextBox()
        Me.TextBox41 = New System.Windows.Forms.TextBox()
        Me.TextBox46 = New System.Windows.Forms.TextBox()
        Me.TextBox43 = New System.Windows.Forms.TextBox()
        Me.TextBox42 = New System.Windows.Forms.TextBox()
        Me.TextBox49 = New System.Windows.Forms.TextBox()
        Me.TextBox50 = New System.Windows.Forms.TextBox()
        Me.TextBox51 = New System.Windows.Forms.TextBox()
        Me.TextBox52 = New System.Windows.Forms.TextBox()
        Me.TextBox53 = New System.Windows.Forms.TextBox()
        Me.TextBox54 = New System.Windows.Forms.TextBox()
        Me.TextBox55 = New System.Windows.Forms.TextBox()
        Me.TextBox56 = New System.Windows.Forms.TextBox()
        Me.TextBox58 = New System.Windows.Forms.TextBox()
        Me.TextBox59 = New System.Windows.Forms.TextBox()
        Me.TextBox60 = New System.Windows.Forms.TextBox()
        Me.TextBox61 = New System.Windows.Forms.TextBox()
        Me.TextBox62 = New System.Windows.Forms.TextBox()
        Me.TextBox63 = New System.Windows.Forms.TextBox()
        Me.CSFList = New System.Windows.Forms.DataGridView()
        Me.FillByToolStrip = New System.Windows.Forms.ToolStrip()
        Me.FillByToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.BatchF = New System.Windows.Forms.RadioButton()
        Me.RadioButton1 = New System.Windows.Forms.RadioButton()
        Me.RadioButton2 = New System.Windows.Forms.RadioButton()
        Me.ColorDialog1 = New System.Windows.Forms.ColorDialog()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.SettingsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PreferenceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TeachersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SubjectsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SectionsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CSFToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RoomsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CourseStructureToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FacultyWiseAllocationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CurrentSessionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CheckTeacherConflictsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CheckRoomConflictsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SetDefaultRoomToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SelctBatchG1ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SelectBatchG2ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RefreshToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TimetablesPreviewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ColorModeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SendEmailsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ActionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UploadLocalPortalToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UploadPDFToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ConvertToSQLITEToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ActionsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PublishToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.ImportNWToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExportTeacherToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExportSubjectToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExportSectionsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExportRoomsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExportCSFToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExportActivitiesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.cbSession = New System.Windows.Forms.ToolStripComboBox()
        Me.cbSection = New System.Windows.Forms.ToolStripComboBox()
        Me.ToolStripButton1 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripTextBox1 = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripButton2 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripButton3 = New System.Windows.Forms.ToolStripButton()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.tsLTPLabel = New System.Windows.Forms.ToolStripStatusLabel()
        Me.rSOE = New System.Windows.Forms.RadioButton()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.rSOHSS = New System.Windows.Forms.RadioButton()
        Me.rSOLJ = New System.Windows.Forms.RadioButton()
        Me.rSOBSC = New System.Windows.Forms.RadioButton()
        Me.rAll = New System.Windows.Forms.RadioButton()
        Me.rSOVSAS = New System.Windows.Forms.RadioButton()
        Me.rSOM = New System.Windows.Forms.RadioButton()
        Me.rSOBT = New System.Windows.Forms.RadioButton()
        Me.rICT = New System.Windows.Forms.RadioButton()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.FillByToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.SchoolToolStripLabel = New System.Windows.Forms.ToolStripLabel()
        Me.SchoolToolStripTextBox = New System.Windows.Forms.ToolStripTextBox()
        Me.FillByToolStripButton1 = New System.Windows.Forms.ToolStripButton()
        Me.userinfo = New System.Windows.Forms.Label()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.VTimeTableBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.MSectionBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ECollegeDataSet = New TimeTableManager.eCollegeDataSet()
        Me.bsProgram = New System.Windows.Forms.BindingSource(Me.components)
        Me.ECollegeDataSet1 = New TimeTableManager.eCollegeDataSet()
        Me.V_TimeTableTableAdapter = New TimeTableManager.eCollegeDataSetTableAdapters.V_TimeTableTableAdapter()
        Me.bsSection = New System.Windows.Forms.BindingSource(Me.components)
        Me.SectionTableAdapter = New TimeTableManager.eCollegeDataSetTableAdapters.SectionTableAdapter()
        Me.ProgramTableAdapter1 = New TimeTableManager.eCollegeDataSetTableAdapters.ProgramTableAdapter()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.ContextMenuStrip1.SuspendLayout()
        CType(Me.CSFList, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.FillByToolStrip.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.FillByToolStrip1.SuspendLayout()
        CType(Me.VTimeTableBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MSectionBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ECollegeDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsProgram, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ECollegeDataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsSection, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.TableLayoutPanel1.BackColor = System.Drawing.Color.White
        Me.TableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset
        Me.TableLayoutPanel1.ColumnCount = 11
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox77, 10, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox76, 10, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox75, 10, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox74, 10, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox73, 10, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox72, 10, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox71, 10, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox70, 9, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox69, 9, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox68, 9, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox67, 9, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox66, 9, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox65, 9, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox64, 9, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox57, 8, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox36, 3, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox33, 0, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox34, 1, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox8, 7, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox35, 2, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox37, 4, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox38, 5, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox39, 6, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox40, 7, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox25, 0, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox26, 1, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox28, 3, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox29, 4, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox30, 5, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox31, 6, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox32, 7, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox17, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox18, 1, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox19, 2, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox20, 3, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox21, 4, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox22, 5, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox23, 6, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox24, 7, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox9, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox10, 1, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox11, 2, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox12, 3, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox13, 4, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox14, 5, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox15, 6, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox16, 7, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox7, 6, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox6, 5, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox5, 4, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox4, 3, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox3, 2, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox2, 1, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox27, 2, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox47, 6, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox48, 7, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox45, 4, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox44, 3, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox41, 0, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox46, 5, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox43, 2, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox42, 1, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox49, 0, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox50, 1, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox51, 2, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox52, 3, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox53, 4, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox54, 5, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox55, 6, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox56, 7, 6)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox58, 8, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox59, 8, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox60, 8, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox61, 8, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox62, 8, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.TextBox63, 8, 6)
        Me.TableLayoutPanel1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TableLayoutPanel1.GrowStyle = System.Windows.Forms.TableLayoutPanelGrowStyle.FixedSize
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(5, 196)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 7
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(891, 421)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.InsertToolStripMenuItem, Me.ToolStripMenuItem3, Me.CopyToolStripMenuItem1, Me.PasteToolStripMenuItem1, Me.SwapToolStripMenuItem, Me.ToolStripSeparator3, Me.DeleteToolStripMenuItem1, Me.QuickInsertToolStripMenuItem})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.System
        Me.ContextMenuStrip1.ShowImageMargin = False
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(156, 164)
        '
        'InsertToolStripMenuItem
        '
        Me.InsertToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem2, Me.DeleteToolStripMenuItem, Me.CopyToolStripMenuItem, Me.PasteToolStripMenuItem})
        Me.InsertToolStripMenuItem.Name = "InsertToolStripMenuItem"
        Me.InsertToolStripMenuItem.Size = New System.Drawing.Size(155, 22)
        Me.InsertToolStripMenuItem.Text = "Insert"
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(107, 22)
        Me.ToolStripMenuItem2.Text = "Insert"
        '
        'DeleteToolStripMenuItem
        '
        Me.DeleteToolStripMenuItem.Name = "DeleteToolStripMenuItem"
        Me.DeleteToolStripMenuItem.Size = New System.Drawing.Size(107, 22)
        Me.DeleteToolStripMenuItem.Text = "Delete"
        '
        'CopyToolStripMenuItem
        '
        Me.CopyToolStripMenuItem.Name = "CopyToolStripMenuItem"
        Me.CopyToolStripMenuItem.Size = New System.Drawing.Size(107, 22)
        Me.CopyToolStripMenuItem.Text = "Copy"
        '
        'PasteToolStripMenuItem
        '
        Me.PasteToolStripMenuItem.Name = "PasteToolStripMenuItem"
        Me.PasteToolStripMenuItem.Size = New System.Drawing.Size(107, 22)
        Me.PasteToolStripMenuItem.Text = "Paste"
        '
        'ToolStripMenuItem3
        '
        Me.ToolStripMenuItem3.Name = "ToolStripMenuItem3"
        Me.ToolStripMenuItem3.Size = New System.Drawing.Size(155, 22)
        Me.ToolStripMenuItem3.Text = "Cut"
        '
        'CopyToolStripMenuItem1
        '
        Me.CopyToolStripMenuItem1.Name = "CopyToolStripMenuItem1"
        Me.CopyToolStripMenuItem1.Size = New System.Drawing.Size(155, 22)
        Me.CopyToolStripMenuItem1.Text = "Copy"
        '
        'PasteToolStripMenuItem1
        '
        Me.PasteToolStripMenuItem1.Name = "PasteToolStripMenuItem1"
        Me.PasteToolStripMenuItem1.Size = New System.Drawing.Size(155, 22)
        Me.PasteToolStripMenuItem1.Text = "Paste"
        '
        'SwapToolStripMenuItem
        '
        Me.SwapToolStripMenuItem.Name = "SwapToolStripMenuItem"
        Me.SwapToolStripMenuItem.Size = New System.Drawing.Size(155, 22)
        Me.SwapToolStripMenuItem.Text = "Select to Swap"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(152, 6)
        '
        'DeleteToolStripMenuItem1
        '
        Me.DeleteToolStripMenuItem1.Name = "DeleteToolStripMenuItem1"
        Me.DeleteToolStripMenuItem1.Size = New System.Drawing.Size(155, 22)
        Me.DeleteToolStripMenuItem1.Text = "Delete"
        '
        'QuickInsertToolStripMenuItem
        '
        Me.QuickInsertToolStripMenuItem.Name = "QuickInsertToolStripMenuItem"
        Me.QuickInsertToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Q), System.Windows.Forms.Keys)
        Me.QuickInsertToolStripMenuItem.Size = New System.Drawing.Size(155, 22)
        Me.QuickInsertToolStripMenuItem.Text = "Quick Insert"
        '
        'TextBox77
        '
        Me.TextBox77.BackColor = System.Drawing.Color.White
        Me.TextBox77.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox77.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox77.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox77.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox77.Location = New System.Drawing.Point(825, 374)
        Me.TextBox77.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox77.Multiline = True
        Me.TextBox77.Name = "TextBox77"
        Me.TextBox77.ReadOnly = True
        Me.TextBox77.Size = New System.Drawing.Size(80, 45)
        Me.TextBox77.TabIndex = 77
        Me.TextBox77.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox76
        '
        Me.TextBox76.BackColor = System.Drawing.Color.White
        Me.TextBox76.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox76.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox76.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox76.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox76.Location = New System.Drawing.Point(825, 312)
        Me.TextBox76.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox76.Multiline = True
        Me.TextBox76.Name = "TextBox76"
        Me.TextBox76.ReadOnly = True
        Me.TextBox76.Size = New System.Drawing.Size(80, 60)
        Me.TextBox76.TabIndex = 76
        Me.TextBox76.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox75
        '
        Me.TextBox75.BackColor = System.Drawing.Color.White
        Me.TextBox75.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox75.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox75.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox75.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox75.Location = New System.Drawing.Point(825, 250)
        Me.TextBox75.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox75.Multiline = True
        Me.TextBox75.Name = "TextBox75"
        Me.TextBox75.ReadOnly = True
        Me.TextBox75.Size = New System.Drawing.Size(80, 60)
        Me.TextBox75.TabIndex = 75
        Me.TextBox75.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox74
        '
        Me.TextBox74.BackColor = System.Drawing.Color.White
        Me.TextBox74.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox74.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox74.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox74.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox74.Location = New System.Drawing.Point(825, 188)
        Me.TextBox74.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox74.Multiline = True
        Me.TextBox74.Name = "TextBox74"
        Me.TextBox74.ReadOnly = True
        Me.TextBox74.Size = New System.Drawing.Size(80, 60)
        Me.TextBox74.TabIndex = 74
        Me.TextBox74.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox73
        '
        Me.TextBox73.BackColor = System.Drawing.Color.White
        Me.TextBox73.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox73.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox73.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox73.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox73.Location = New System.Drawing.Point(825, 126)
        Me.TextBox73.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox73.Multiline = True
        Me.TextBox73.Name = "TextBox73"
        Me.TextBox73.ReadOnly = True
        Me.TextBox73.Size = New System.Drawing.Size(80, 60)
        Me.TextBox73.TabIndex = 73
        Me.TextBox73.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox72
        '
        Me.TextBox72.BackColor = System.Drawing.Color.White
        Me.TextBox72.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox72.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox72.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox72.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox72.Location = New System.Drawing.Point(825, 64)
        Me.TextBox72.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox72.Multiline = True
        Me.TextBox72.Name = "TextBox72"
        Me.TextBox72.ReadOnly = True
        Me.TextBox72.Size = New System.Drawing.Size(80, 60)
        Me.TextBox72.TabIndex = 72
        Me.TextBox72.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox71
        '
        Me.TextBox71.BackColor = System.Drawing.Color.White
        Me.TextBox71.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox71.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox71.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox71.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox71.Location = New System.Drawing.Point(825, 2)
        Me.TextBox71.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox71.Multiline = True
        Me.TextBox71.Name = "TextBox71"
        Me.TextBox71.ReadOnly = True
        Me.TextBox71.Size = New System.Drawing.Size(80, 60)
        Me.TextBox71.TabIndex = 71
        Me.TextBox71.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox70
        '
        Me.TextBox70.BackColor = System.Drawing.Color.White
        Me.TextBox70.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox70.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox70.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox70.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox70.Location = New System.Drawing.Point(743, 374)
        Me.TextBox70.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox70.Multiline = True
        Me.TextBox70.Name = "TextBox70"
        Me.TextBox70.ReadOnly = True
        Me.TextBox70.Size = New System.Drawing.Size(80, 45)
        Me.TextBox70.TabIndex = 70
        Me.TextBox70.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox69
        '
        Me.TextBox69.BackColor = System.Drawing.Color.White
        Me.TextBox69.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox69.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox69.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox69.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox69.Location = New System.Drawing.Point(743, 312)
        Me.TextBox69.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox69.Multiline = True
        Me.TextBox69.Name = "TextBox69"
        Me.TextBox69.ReadOnly = True
        Me.TextBox69.Size = New System.Drawing.Size(80, 60)
        Me.TextBox69.TabIndex = 69
        Me.TextBox69.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox68
        '
        Me.TextBox68.BackColor = System.Drawing.Color.White
        Me.TextBox68.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox68.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox68.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox68.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox68.Location = New System.Drawing.Point(743, 250)
        Me.TextBox68.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox68.Multiline = True
        Me.TextBox68.Name = "TextBox68"
        Me.TextBox68.ReadOnly = True
        Me.TextBox68.Size = New System.Drawing.Size(80, 60)
        Me.TextBox68.TabIndex = 68
        Me.TextBox68.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox67
        '
        Me.TextBox67.BackColor = System.Drawing.Color.White
        Me.TextBox67.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox67.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox67.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox67.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox67.Location = New System.Drawing.Point(743, 188)
        Me.TextBox67.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox67.Multiline = True
        Me.TextBox67.Name = "TextBox67"
        Me.TextBox67.ReadOnly = True
        Me.TextBox67.Size = New System.Drawing.Size(80, 60)
        Me.TextBox67.TabIndex = 67
        Me.TextBox67.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox66
        '
        Me.TextBox66.BackColor = System.Drawing.Color.White
        Me.TextBox66.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox66.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox66.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox66.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox66.Location = New System.Drawing.Point(743, 126)
        Me.TextBox66.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox66.Multiline = True
        Me.TextBox66.Name = "TextBox66"
        Me.TextBox66.ReadOnly = True
        Me.TextBox66.Size = New System.Drawing.Size(80, 60)
        Me.TextBox66.TabIndex = 66
        Me.TextBox66.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox65
        '
        Me.TextBox65.BackColor = System.Drawing.Color.White
        Me.TextBox65.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox65.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox65.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox65.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox65.Location = New System.Drawing.Point(743, 64)
        Me.TextBox65.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox65.Multiline = True
        Me.TextBox65.Name = "TextBox65"
        Me.TextBox65.ReadOnly = True
        Me.TextBox65.Size = New System.Drawing.Size(80, 60)
        Me.TextBox65.TabIndex = 65
        Me.TextBox65.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox64
        '
        Me.TextBox64.BackColor = System.Drawing.Color.White
        Me.TextBox64.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox64.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox64.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox64.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox64.Location = New System.Drawing.Point(743, 2)
        Me.TextBox64.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox64.Multiline = True
        Me.TextBox64.Name = "TextBox64"
        Me.TextBox64.ReadOnly = True
        Me.TextBox64.Size = New System.Drawing.Size(80, 60)
        Me.TextBox64.TabIndex = 64
        Me.TextBox64.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox57
        '
        Me.TextBox57.BackColor = System.Drawing.Color.White
        Me.TextBox57.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox57.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox57.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox57.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox57.Location = New System.Drawing.Point(661, 2)
        Me.TextBox57.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox57.Multiline = True
        Me.TextBox57.Name = "TextBox57"
        Me.TextBox57.ReadOnly = True
        Me.TextBox57.Size = New System.Drawing.Size(80, 60)
        Me.TextBox57.TabIndex = 57
        Me.TextBox57.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox36
        '
        Me.TextBox36.BackColor = System.Drawing.Color.White
        Me.TextBox36.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox36.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox36.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox36.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox36.Location = New System.Drawing.Point(251, 250)
        Me.TextBox36.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox36.Multiline = True
        Me.TextBox36.Name = "TextBox36"
        Me.TextBox36.ReadOnly = True
        Me.TextBox36.Size = New System.Drawing.Size(80, 60)
        Me.TextBox36.TabIndex = 36
        Me.TextBox36.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox33
        '
        Me.TextBox33.BackColor = System.Drawing.Color.White
        Me.TextBox33.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox33.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox33.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox33.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox33.Location = New System.Drawing.Point(2, 250)
        Me.TextBox33.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox33.Multiline = True
        Me.TextBox33.Name = "TextBox33"
        Me.TextBox33.ReadOnly = True
        Me.TextBox33.Size = New System.Drawing.Size(80, 60)
        Me.TextBox33.TabIndex = 33
        Me.TextBox33.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox34
        '
        Me.TextBox34.BackColor = System.Drawing.Color.White
        Me.TextBox34.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox34.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox34.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox34.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox34.Location = New System.Drawing.Point(85, 250)
        Me.TextBox34.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox34.Multiline = True
        Me.TextBox34.Name = "TextBox34"
        Me.TextBox34.ReadOnly = True
        Me.TextBox34.Size = New System.Drawing.Size(80, 60)
        Me.TextBox34.TabIndex = 34
        Me.TextBox34.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox8
        '
        Me.TextBox8.BackColor = System.Drawing.Color.White
        Me.TextBox8.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox8.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox8.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox8.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox8.Location = New System.Drawing.Point(579, 2)
        Me.TextBox8.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox8.Multiline = True
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.ReadOnly = True
        Me.TextBox8.Size = New System.Drawing.Size(80, 60)
        Me.TextBox8.TabIndex = 8
        Me.TextBox8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox35
        '
        Me.TextBox35.BackColor = System.Drawing.Color.White
        Me.TextBox35.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox35.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox35.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox35.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox35.Location = New System.Drawing.Point(167, 250)
        Me.TextBox35.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox35.Multiline = True
        Me.TextBox35.Name = "TextBox35"
        Me.TextBox35.ReadOnly = True
        Me.TextBox35.Size = New System.Drawing.Size(80, 60)
        Me.TextBox35.TabIndex = 35
        Me.TextBox35.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox37
        '
        Me.TextBox37.BackColor = System.Drawing.Color.White
        Me.TextBox37.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox37.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox37.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox37.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox37.Location = New System.Drawing.Point(333, 250)
        Me.TextBox37.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox37.Multiline = True
        Me.TextBox37.Name = "TextBox37"
        Me.TextBox37.ReadOnly = True
        Me.TextBox37.Size = New System.Drawing.Size(80, 60)
        Me.TextBox37.TabIndex = 37
        Me.TextBox37.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox38
        '
        Me.TextBox38.BackColor = System.Drawing.Color.White
        Me.TextBox38.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox38.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox38.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox38.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox38.Location = New System.Drawing.Point(415, 250)
        Me.TextBox38.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox38.Multiline = True
        Me.TextBox38.Name = "TextBox38"
        Me.TextBox38.ReadOnly = True
        Me.TextBox38.Size = New System.Drawing.Size(80, 60)
        Me.TextBox38.TabIndex = 38
        Me.TextBox38.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox39
        '
        Me.TextBox39.BackColor = System.Drawing.Color.White
        Me.TextBox39.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox39.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox39.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox39.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox39.Location = New System.Drawing.Point(497, 250)
        Me.TextBox39.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox39.Multiline = True
        Me.TextBox39.Name = "TextBox39"
        Me.TextBox39.ReadOnly = True
        Me.TextBox39.Size = New System.Drawing.Size(80, 60)
        Me.TextBox39.TabIndex = 39
        Me.TextBox39.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox40
        '
        Me.TextBox40.BackColor = System.Drawing.Color.White
        Me.TextBox40.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox40.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox40.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox40.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox40.Location = New System.Drawing.Point(579, 250)
        Me.TextBox40.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox40.Multiline = True
        Me.TextBox40.Name = "TextBox40"
        Me.TextBox40.ReadOnly = True
        Me.TextBox40.Size = New System.Drawing.Size(80, 60)
        Me.TextBox40.TabIndex = 40
        Me.TextBox40.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox25
        '
        Me.TextBox25.BackColor = System.Drawing.Color.White
        Me.TextBox25.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox25.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox25.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox25.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox25.Location = New System.Drawing.Point(2, 188)
        Me.TextBox25.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox25.Multiline = True
        Me.TextBox25.Name = "TextBox25"
        Me.TextBox25.ReadOnly = True
        Me.TextBox25.Size = New System.Drawing.Size(80, 60)
        Me.TextBox25.TabIndex = 25
        Me.TextBox25.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox26
        '
        Me.TextBox26.BackColor = System.Drawing.Color.White
        Me.TextBox26.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox26.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox26.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox26.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox26.Location = New System.Drawing.Point(85, 188)
        Me.TextBox26.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox26.Multiline = True
        Me.TextBox26.Name = "TextBox26"
        Me.TextBox26.ReadOnly = True
        Me.TextBox26.Size = New System.Drawing.Size(80, 60)
        Me.TextBox26.TabIndex = 26
        Me.TextBox26.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox28
        '
        Me.TextBox28.BackColor = System.Drawing.Color.White
        Me.TextBox28.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox28.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox28.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox28.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox28.Location = New System.Drawing.Point(251, 188)
        Me.TextBox28.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox28.Multiline = True
        Me.TextBox28.Name = "TextBox28"
        Me.TextBox28.ReadOnly = True
        Me.TextBox28.Size = New System.Drawing.Size(80, 60)
        Me.TextBox28.TabIndex = 28
        Me.TextBox28.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox29
        '
        Me.TextBox29.BackColor = System.Drawing.Color.White
        Me.TextBox29.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox29.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox29.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox29.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox29.Location = New System.Drawing.Point(333, 188)
        Me.TextBox29.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox29.Multiline = True
        Me.TextBox29.Name = "TextBox29"
        Me.TextBox29.ReadOnly = True
        Me.TextBox29.Size = New System.Drawing.Size(80, 60)
        Me.TextBox29.TabIndex = 29
        Me.TextBox29.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox30
        '
        Me.TextBox30.BackColor = System.Drawing.Color.White
        Me.TextBox30.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox30.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox30.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox30.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox30.Location = New System.Drawing.Point(415, 188)
        Me.TextBox30.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox30.Multiline = True
        Me.TextBox30.Name = "TextBox30"
        Me.TextBox30.ReadOnly = True
        Me.TextBox30.Size = New System.Drawing.Size(80, 60)
        Me.TextBox30.TabIndex = 30
        Me.TextBox30.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox31
        '
        Me.TextBox31.BackColor = System.Drawing.Color.White
        Me.TextBox31.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox31.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox31.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox31.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox31.Location = New System.Drawing.Point(497, 188)
        Me.TextBox31.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox31.Multiline = True
        Me.TextBox31.Name = "TextBox31"
        Me.TextBox31.ReadOnly = True
        Me.TextBox31.Size = New System.Drawing.Size(80, 60)
        Me.TextBox31.TabIndex = 31
        Me.TextBox31.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox32
        '
        Me.TextBox32.BackColor = System.Drawing.Color.White
        Me.TextBox32.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox32.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox32.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox32.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox32.Location = New System.Drawing.Point(579, 188)
        Me.TextBox32.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox32.Multiline = True
        Me.TextBox32.Name = "TextBox32"
        Me.TextBox32.ReadOnly = True
        Me.TextBox32.Size = New System.Drawing.Size(80, 60)
        Me.TextBox32.TabIndex = 32
        Me.TextBox32.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox17
        '
        Me.TextBox17.BackColor = System.Drawing.Color.White
        Me.TextBox17.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox17.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox17.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox17.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox17.Location = New System.Drawing.Point(2, 126)
        Me.TextBox17.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox17.Multiline = True
        Me.TextBox17.Name = "TextBox17"
        Me.TextBox17.ReadOnly = True
        Me.TextBox17.Size = New System.Drawing.Size(80, 60)
        Me.TextBox17.TabIndex = 17
        Me.TextBox17.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox18
        '
        Me.TextBox18.BackColor = System.Drawing.Color.White
        Me.TextBox18.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox18.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox18.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox18.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox18.Location = New System.Drawing.Point(85, 126)
        Me.TextBox18.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox18.Multiline = True
        Me.TextBox18.Name = "TextBox18"
        Me.TextBox18.ReadOnly = True
        Me.TextBox18.Size = New System.Drawing.Size(80, 60)
        Me.TextBox18.TabIndex = 18
        Me.TextBox18.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox19
        '
        Me.TextBox19.BackColor = System.Drawing.Color.White
        Me.TextBox19.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox19.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox19.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox19.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox19.Location = New System.Drawing.Point(167, 126)
        Me.TextBox19.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox19.Multiline = True
        Me.TextBox19.Name = "TextBox19"
        Me.TextBox19.ReadOnly = True
        Me.TextBox19.Size = New System.Drawing.Size(80, 60)
        Me.TextBox19.TabIndex = 19
        Me.TextBox19.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox20
        '
        Me.TextBox20.BackColor = System.Drawing.Color.White
        Me.TextBox20.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox20.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox20.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox20.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox20.Location = New System.Drawing.Point(251, 126)
        Me.TextBox20.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox20.Multiline = True
        Me.TextBox20.Name = "TextBox20"
        Me.TextBox20.ReadOnly = True
        Me.TextBox20.Size = New System.Drawing.Size(80, 60)
        Me.TextBox20.TabIndex = 20
        Me.TextBox20.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox21
        '
        Me.TextBox21.BackColor = System.Drawing.Color.White
        Me.TextBox21.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox21.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox21.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox21.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox21.Location = New System.Drawing.Point(333, 126)
        Me.TextBox21.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox21.Multiline = True
        Me.TextBox21.Name = "TextBox21"
        Me.TextBox21.ReadOnly = True
        Me.TextBox21.Size = New System.Drawing.Size(80, 60)
        Me.TextBox21.TabIndex = 21
        Me.TextBox21.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox22
        '
        Me.TextBox22.BackColor = System.Drawing.Color.White
        Me.TextBox22.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox22.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox22.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox22.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox22.Location = New System.Drawing.Point(415, 126)
        Me.TextBox22.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox22.Multiline = True
        Me.TextBox22.Name = "TextBox22"
        Me.TextBox22.ReadOnly = True
        Me.TextBox22.Size = New System.Drawing.Size(80, 60)
        Me.TextBox22.TabIndex = 22
        Me.TextBox22.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox23
        '
        Me.TextBox23.BackColor = System.Drawing.Color.White
        Me.TextBox23.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox23.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox23.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox23.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox23.Location = New System.Drawing.Point(497, 126)
        Me.TextBox23.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox23.Multiline = True
        Me.TextBox23.Name = "TextBox23"
        Me.TextBox23.ReadOnly = True
        Me.TextBox23.Size = New System.Drawing.Size(80, 60)
        Me.TextBox23.TabIndex = 23
        Me.TextBox23.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox24
        '
        Me.TextBox24.BackColor = System.Drawing.Color.White
        Me.TextBox24.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox24.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox24.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox24.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox24.Location = New System.Drawing.Point(579, 126)
        Me.TextBox24.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox24.Multiline = True
        Me.TextBox24.Name = "TextBox24"
        Me.TextBox24.ReadOnly = True
        Me.TextBox24.Size = New System.Drawing.Size(80, 60)
        Me.TextBox24.TabIndex = 24
        Me.TextBox24.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox9
        '
        Me.TextBox9.BackColor = System.Drawing.Color.White
        Me.TextBox9.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox9.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox9.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox9.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox9.Location = New System.Drawing.Point(2, 64)
        Me.TextBox9.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox9.Multiline = True
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.ReadOnly = True
        Me.TextBox9.Size = New System.Drawing.Size(80, 60)
        Me.TextBox9.TabIndex = 9
        Me.TextBox9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox10
        '
        Me.TextBox10.BackColor = System.Drawing.Color.White
        Me.TextBox10.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox10.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox10.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox10.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox10.Location = New System.Drawing.Point(85, 64)
        Me.TextBox10.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox10.Multiline = True
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.ReadOnly = True
        Me.TextBox10.Size = New System.Drawing.Size(80, 60)
        Me.TextBox10.TabIndex = 10
        Me.TextBox10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox11
        '
        Me.TextBox11.BackColor = System.Drawing.Color.White
        Me.TextBox11.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox11.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox11.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox11.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox11.Location = New System.Drawing.Point(167, 64)
        Me.TextBox11.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox11.Multiline = True
        Me.TextBox11.Name = "TextBox11"
        Me.TextBox11.ReadOnly = True
        Me.TextBox11.Size = New System.Drawing.Size(80, 60)
        Me.TextBox11.TabIndex = 11
        Me.TextBox11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox12
        '
        Me.TextBox12.BackColor = System.Drawing.Color.White
        Me.TextBox12.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox12.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox12.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox12.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox12.Location = New System.Drawing.Point(251, 64)
        Me.TextBox12.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox12.Multiline = True
        Me.TextBox12.Name = "TextBox12"
        Me.TextBox12.ReadOnly = True
        Me.TextBox12.Size = New System.Drawing.Size(80, 60)
        Me.TextBox12.TabIndex = 12
        Me.TextBox12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox13
        '
        Me.TextBox13.BackColor = System.Drawing.Color.White
        Me.TextBox13.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox13.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox13.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox13.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox13.Location = New System.Drawing.Point(333, 64)
        Me.TextBox13.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox13.Multiline = True
        Me.TextBox13.Name = "TextBox13"
        Me.TextBox13.ReadOnly = True
        Me.TextBox13.Size = New System.Drawing.Size(80, 60)
        Me.TextBox13.TabIndex = 13
        Me.TextBox13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox14
        '
        Me.TextBox14.BackColor = System.Drawing.Color.White
        Me.TextBox14.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox14.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox14.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox14.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox14.Location = New System.Drawing.Point(415, 64)
        Me.TextBox14.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox14.Multiline = True
        Me.TextBox14.Name = "TextBox14"
        Me.TextBox14.ReadOnly = True
        Me.TextBox14.Size = New System.Drawing.Size(80, 60)
        Me.TextBox14.TabIndex = 14
        Me.TextBox14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox15
        '
        Me.TextBox15.BackColor = System.Drawing.Color.White
        Me.TextBox15.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox15.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox15.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox15.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox15.Location = New System.Drawing.Point(497, 64)
        Me.TextBox15.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox15.Multiline = True
        Me.TextBox15.Name = "TextBox15"
        Me.TextBox15.ReadOnly = True
        Me.TextBox15.Size = New System.Drawing.Size(80, 60)
        Me.TextBox15.TabIndex = 15
        Me.TextBox15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox16
        '
        Me.TextBox16.BackColor = System.Drawing.Color.White
        Me.TextBox16.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox16.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox16.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox16.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox16.Location = New System.Drawing.Point(579, 64)
        Me.TextBox16.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox16.Multiline = True
        Me.TextBox16.Name = "TextBox16"
        Me.TextBox16.ReadOnly = True
        Me.TextBox16.Size = New System.Drawing.Size(80, 60)
        Me.TextBox16.TabIndex = 16
        Me.TextBox16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox7
        '
        Me.TextBox7.BackColor = System.Drawing.Color.White
        Me.TextBox7.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox7.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox7.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox7.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox7.Location = New System.Drawing.Point(497, 2)
        Me.TextBox7.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox7.Multiline = True
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.ReadOnly = True
        Me.TextBox7.Size = New System.Drawing.Size(80, 60)
        Me.TextBox7.TabIndex = 7
        Me.TextBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox6
        '
        Me.TextBox6.BackColor = System.Drawing.Color.White
        Me.TextBox6.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox6.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox6.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox6.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox6.Location = New System.Drawing.Point(415, 2)
        Me.TextBox6.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox6.Multiline = True
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.ReadOnly = True
        Me.TextBox6.Size = New System.Drawing.Size(80, 60)
        Me.TextBox6.TabIndex = 6
        Me.TextBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox5
        '
        Me.TextBox5.BackColor = System.Drawing.Color.White
        Me.TextBox5.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox5.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox5.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox5.Location = New System.Drawing.Point(333, 2)
        Me.TextBox5.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox5.Multiline = True
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.ReadOnly = True
        Me.TextBox5.Size = New System.Drawing.Size(80, 60)
        Me.TextBox5.TabIndex = 5
        Me.TextBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox4
        '
        Me.TextBox4.BackColor = System.Drawing.Color.White
        Me.TextBox4.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox4.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox4.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox4.Location = New System.Drawing.Point(251, 2)
        Me.TextBox4.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox4.Multiline = True
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.ReadOnly = True
        Me.TextBox4.Size = New System.Drawing.Size(80, 60)
        Me.TextBox4.TabIndex = 4
        Me.TextBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox3
        '
        Me.TextBox3.BackColor = System.Drawing.Color.White
        Me.TextBox3.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox3.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox3.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox3.Location = New System.Drawing.Point(167, 2)
        Me.TextBox3.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox3.Multiline = True
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.ReadOnly = True
        Me.TextBox3.Size = New System.Drawing.Size(82, 60)
        Me.TextBox3.TabIndex = 3
        Me.TextBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox2
        '
        Me.TextBox2.BackColor = System.Drawing.Color.White
        Me.TextBox2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox2.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox2.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox2.Location = New System.Drawing.Point(85, 2)
        Me.TextBox2.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox2.Multiline = True
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.ReadOnly = True
        Me.TextBox2.Size = New System.Drawing.Size(80, 60)
        Me.TextBox2.TabIndex = 2
        Me.TextBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.Color.White
        Me.TextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox1.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox1.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(2, 2)
        Me.TextBox1.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ReadOnly = True
        Me.TextBox1.Size = New System.Drawing.Size(81, 60)
        Me.TextBox1.TabIndex = 1
        Me.TextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox27
        '
        Me.TextBox27.BackColor = System.Drawing.Color.White
        Me.TextBox27.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox27.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox27.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox27.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox27.Location = New System.Drawing.Point(167, 188)
        Me.TextBox27.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox27.Multiline = True
        Me.TextBox27.Name = "TextBox27"
        Me.TextBox27.ReadOnly = True
        Me.TextBox27.Size = New System.Drawing.Size(80, 60)
        Me.TextBox27.TabIndex = 27
        Me.TextBox27.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox47
        '
        Me.TextBox47.BackColor = System.Drawing.Color.White
        Me.TextBox47.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox47.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox47.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox47.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox47.Location = New System.Drawing.Point(497, 312)
        Me.TextBox47.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox47.Multiline = True
        Me.TextBox47.Name = "TextBox47"
        Me.TextBox47.ReadOnly = True
        Me.TextBox47.Size = New System.Drawing.Size(80, 60)
        Me.TextBox47.TabIndex = 47
        Me.TextBox47.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox48
        '
        Me.TextBox48.AcceptsTab = True
        Me.TextBox48.BackColor = System.Drawing.Color.White
        Me.TextBox48.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox48.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox48.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox48.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox48.Location = New System.Drawing.Point(579, 312)
        Me.TextBox48.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox48.Multiline = True
        Me.TextBox48.Name = "TextBox48"
        Me.TextBox48.ReadOnly = True
        Me.TextBox48.Size = New System.Drawing.Size(80, 60)
        Me.TextBox48.TabIndex = 48
        Me.TextBox48.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox45
        '
        Me.TextBox45.BackColor = System.Drawing.Color.White
        Me.TextBox45.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox45.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox45.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox45.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox45.Location = New System.Drawing.Point(333, 312)
        Me.TextBox45.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox45.Multiline = True
        Me.TextBox45.Name = "TextBox45"
        Me.TextBox45.ReadOnly = True
        Me.TextBox45.Size = New System.Drawing.Size(80, 60)
        Me.TextBox45.TabIndex = 45
        Me.TextBox45.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox44
        '
        Me.TextBox44.BackColor = System.Drawing.Color.White
        Me.TextBox44.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox44.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox44.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox44.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox44.Location = New System.Drawing.Point(251, 312)
        Me.TextBox44.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox44.Multiline = True
        Me.TextBox44.Name = "TextBox44"
        Me.TextBox44.ReadOnly = True
        Me.TextBox44.Size = New System.Drawing.Size(80, 60)
        Me.TextBox44.TabIndex = 44
        Me.TextBox44.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox41
        '
        Me.TextBox41.BackColor = System.Drawing.Color.White
        Me.TextBox41.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox41.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox41.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox41.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox41.Location = New System.Drawing.Point(2, 312)
        Me.TextBox41.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox41.Multiline = True
        Me.TextBox41.Name = "TextBox41"
        Me.TextBox41.ReadOnly = True
        Me.TextBox41.Size = New System.Drawing.Size(80, 60)
        Me.TextBox41.TabIndex = 41
        Me.TextBox41.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox46
        '
        Me.TextBox46.BackColor = System.Drawing.Color.White
        Me.TextBox46.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox46.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox46.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox46.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox46.Location = New System.Drawing.Point(415, 312)
        Me.TextBox46.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox46.Multiline = True
        Me.TextBox46.Name = "TextBox46"
        Me.TextBox46.ReadOnly = True
        Me.TextBox46.Size = New System.Drawing.Size(80, 60)
        Me.TextBox46.TabIndex = 46
        Me.TextBox46.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox43
        '
        Me.TextBox43.BackColor = System.Drawing.Color.White
        Me.TextBox43.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox43.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox43.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox43.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox43.Location = New System.Drawing.Point(167, 312)
        Me.TextBox43.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox43.Multiline = True
        Me.TextBox43.Name = "TextBox43"
        Me.TextBox43.ReadOnly = True
        Me.TextBox43.Size = New System.Drawing.Size(80, 60)
        Me.TextBox43.TabIndex = 43
        Me.TextBox43.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox42
        '
        Me.TextBox42.BackColor = System.Drawing.Color.White
        Me.TextBox42.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox42.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox42.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox42.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox42.Location = New System.Drawing.Point(85, 312)
        Me.TextBox42.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox42.Multiline = True
        Me.TextBox42.Name = "TextBox42"
        Me.TextBox42.ReadOnly = True
        Me.TextBox42.Size = New System.Drawing.Size(80, 60)
        Me.TextBox42.TabIndex = 42
        Me.TextBox42.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox49
        '
        Me.TextBox49.BackColor = System.Drawing.Color.White
        Me.TextBox49.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox49.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox49.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox49.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox49.Location = New System.Drawing.Point(2, 374)
        Me.TextBox49.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox49.Multiline = True
        Me.TextBox49.Name = "TextBox49"
        Me.TextBox49.ReadOnly = True
        Me.TextBox49.Size = New System.Drawing.Size(80, 45)
        Me.TextBox49.TabIndex = 49
        Me.TextBox49.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox50
        '
        Me.TextBox50.BackColor = System.Drawing.Color.White
        Me.TextBox50.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox50.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox50.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox50.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox50.Location = New System.Drawing.Point(85, 374)
        Me.TextBox50.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox50.Multiline = True
        Me.TextBox50.Name = "TextBox50"
        Me.TextBox50.ReadOnly = True
        Me.TextBox50.Size = New System.Drawing.Size(80, 45)
        Me.TextBox50.TabIndex = 50
        Me.TextBox50.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox51
        '
        Me.TextBox51.BackColor = System.Drawing.Color.White
        Me.TextBox51.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox51.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox51.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox51.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox51.Location = New System.Drawing.Point(167, 374)
        Me.TextBox51.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox51.Multiline = True
        Me.TextBox51.Name = "TextBox51"
        Me.TextBox51.ReadOnly = True
        Me.TextBox51.Size = New System.Drawing.Size(80, 45)
        Me.TextBox51.TabIndex = 51
        Me.TextBox51.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox52
        '
        Me.TextBox52.BackColor = System.Drawing.Color.White
        Me.TextBox52.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox52.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox52.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox52.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox52.Location = New System.Drawing.Point(251, 374)
        Me.TextBox52.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox52.Multiline = True
        Me.TextBox52.Name = "TextBox52"
        Me.TextBox52.ReadOnly = True
        Me.TextBox52.Size = New System.Drawing.Size(80, 45)
        Me.TextBox52.TabIndex = 52
        Me.TextBox52.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox53
        '
        Me.TextBox53.BackColor = System.Drawing.Color.White
        Me.TextBox53.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox53.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox53.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox53.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox53.Location = New System.Drawing.Point(333, 374)
        Me.TextBox53.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox53.Multiline = True
        Me.TextBox53.Name = "TextBox53"
        Me.TextBox53.ReadOnly = True
        Me.TextBox53.Size = New System.Drawing.Size(80, 45)
        Me.TextBox53.TabIndex = 53
        Me.TextBox53.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox54
        '
        Me.TextBox54.BackColor = System.Drawing.Color.White
        Me.TextBox54.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox54.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox54.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox54.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox54.Location = New System.Drawing.Point(415, 374)
        Me.TextBox54.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox54.Multiline = True
        Me.TextBox54.Name = "TextBox54"
        Me.TextBox54.ReadOnly = True
        Me.TextBox54.Size = New System.Drawing.Size(80, 45)
        Me.TextBox54.TabIndex = 54
        Me.TextBox54.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox55
        '
        Me.TextBox55.BackColor = System.Drawing.Color.White
        Me.TextBox55.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox55.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox55.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox55.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox55.Location = New System.Drawing.Point(497, 374)
        Me.TextBox55.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox55.Multiline = True
        Me.TextBox55.Name = "TextBox55"
        Me.TextBox55.ReadOnly = True
        Me.TextBox55.Size = New System.Drawing.Size(80, 45)
        Me.TextBox55.TabIndex = 55
        Me.TextBox55.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox56
        '
        Me.TextBox56.BackColor = System.Drawing.Color.White
        Me.TextBox56.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox56.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox56.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox56.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox56.Location = New System.Drawing.Point(579, 374)
        Me.TextBox56.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox56.Multiline = True
        Me.TextBox56.Name = "TextBox56"
        Me.TextBox56.ReadOnly = True
        Me.TextBox56.Size = New System.Drawing.Size(80, 45)
        Me.TextBox56.TabIndex = 56
        Me.TextBox56.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox58
        '
        Me.TextBox58.BackColor = System.Drawing.Color.White
        Me.TextBox58.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox58.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox58.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox58.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox58.Location = New System.Drawing.Point(661, 64)
        Me.TextBox58.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox58.Multiline = True
        Me.TextBox58.Name = "TextBox58"
        Me.TextBox58.ReadOnly = True
        Me.TextBox58.Size = New System.Drawing.Size(80, 60)
        Me.TextBox58.TabIndex = 58
        Me.TextBox58.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox59
        '
        Me.TextBox59.BackColor = System.Drawing.Color.White
        Me.TextBox59.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox59.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox59.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox59.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox59.Location = New System.Drawing.Point(661, 126)
        Me.TextBox59.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox59.Multiline = True
        Me.TextBox59.Name = "TextBox59"
        Me.TextBox59.ReadOnly = True
        Me.TextBox59.Size = New System.Drawing.Size(80, 60)
        Me.TextBox59.TabIndex = 59
        Me.TextBox59.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox60
        '
        Me.TextBox60.BackColor = System.Drawing.Color.White
        Me.TextBox60.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox60.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox60.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox60.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox60.Location = New System.Drawing.Point(661, 188)
        Me.TextBox60.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox60.Multiline = True
        Me.TextBox60.Name = "TextBox60"
        Me.TextBox60.ReadOnly = True
        Me.TextBox60.Size = New System.Drawing.Size(80, 60)
        Me.TextBox60.TabIndex = 60
        Me.TextBox60.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox61
        '
        Me.TextBox61.BackColor = System.Drawing.Color.White
        Me.TextBox61.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox61.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox61.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox61.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox61.Location = New System.Drawing.Point(661, 250)
        Me.TextBox61.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox61.Multiline = True
        Me.TextBox61.Name = "TextBox61"
        Me.TextBox61.ReadOnly = True
        Me.TextBox61.Size = New System.Drawing.Size(80, 60)
        Me.TextBox61.TabIndex = 61
        Me.TextBox61.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox62
        '
        Me.TextBox62.BackColor = System.Drawing.Color.White
        Me.TextBox62.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox62.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox62.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox62.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox62.Location = New System.Drawing.Point(661, 312)
        Me.TextBox62.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox62.Multiline = True
        Me.TextBox62.Name = "TextBox62"
        Me.TextBox62.ReadOnly = True
        Me.TextBox62.Size = New System.Drawing.Size(80, 60)
        Me.TextBox62.TabIndex = 62
        Me.TextBox62.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox63
        '
        Me.TextBox63.BackColor = System.Drawing.Color.White
        Me.TextBox63.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox63.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox63.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TextBox63.Font = New System.Drawing.Font("Verdana", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox63.Location = New System.Drawing.Point(661, 374)
        Me.TextBox63.Margin = New System.Windows.Forms.Padding(0)
        Me.TextBox63.Multiline = True
        Me.TextBox63.Name = "TextBox63"
        Me.TextBox63.ReadOnly = True
        Me.TextBox63.Size = New System.Drawing.Size(80, 45)
        Me.TextBox63.TabIndex = 63
        Me.TextBox63.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'CSFList
        '
        Me.CSFList.AllowUserToAddRows = False
        Me.CSFList.AllowUserToDeleteRows = False
        Me.CSFList.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.CSFList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCellsExceptHeader
        Me.CSFList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.CSFList.Location = New System.Drawing.Point(12, 52)
        Me.CSFList.MultiSelect = False
        Me.CSFList.Name = "CSFList"
        Me.CSFList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.CSFList.Size = New System.Drawing.Size(824, 138)
        Me.CSFList.TabIndex = 0
        '
        'FillByToolStrip
        '
        Me.FillByToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FillByToolStripButton})
        Me.FillByToolStrip.Location = New System.Drawing.Point(0, 24)
        Me.FillByToolStrip.Name = "FillByToolStrip"
        Me.FillByToolStrip.Size = New System.Drawing.Size(986, 25)
        Me.FillByToolStrip.TabIndex = 7
        Me.FillByToolStrip.Text = "FillByToolStrip"
        Me.FillByToolStrip.Visible = False
        '
        'FillByToolStripButton
        '
        Me.FillByToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.FillByToolStripButton.Name = "FillByToolStripButton"
        Me.FillByToolStripButton.Size = New System.Drawing.Size(39, 22)
        Me.FillByToolStripButton.Text = "FillBy"
        '
        'BatchF
        '
        Me.BatchF.AutoSize = True
        Me.BatchF.Checked = True
        Me.BatchF.Location = New System.Drawing.Point(372, 4)
        Me.BatchF.Name = "BatchF"
        Me.BatchF.Size = New System.Drawing.Size(41, 17)
        Me.BatchF.TabIndex = 10
        Me.BatchF.TabStop = True
        Me.BatchF.Text = "Full"
        Me.BatchF.UseVisualStyleBackColor = True
        '
        'RadioButton1
        '
        Me.RadioButton1.AutoSize = True
        Me.RadioButton1.Location = New System.Drawing.Point(419, 4)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(62, 17)
        Me.RadioButton1.TabIndex = 11
        Me.RadioButton1.Text = "Batch-1"
        Me.RadioButton1.UseVisualStyleBackColor = True
        '
        'RadioButton2
        '
        Me.RadioButton2.AutoSize = True
        Me.RadioButton2.Location = New System.Drawing.Point(487, 4)
        Me.RadioButton2.Name = "RadioButton2"
        Me.RadioButton2.Size = New System.Drawing.Size(62, 17)
        Me.RadioButton2.TabIndex = 12
        Me.RadioButton2.Text = "Batch-2"
        Me.RadioButton2.UseVisualStyleBackColor = True
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SettingsToolStripMenuItem, Me.HelpToolStripMenuItem, Me.ToolsToolStripMenuItem, Me.ActionToolStripMenuItem, Me.ActionsToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
        Me.MenuStrip1.Size = New System.Drawing.Size(1202, 24)
        Me.MenuStrip1.TabIndex = 14
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'SettingsToolStripMenuItem
        '
        Me.SettingsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PreferenceToolStripMenuItem, Me.TeachersToolStripMenuItem, Me.ToolStripMenuItem1, Me.SubjectsToolStripMenuItem, Me.SectionsToolStripMenuItem, Me.ToolStripMenuItem4, Me.CSFToolStripMenuItem, Me.RoomsToolStripMenuItem, Me.CourseStructureToolStripMenuItem, Me.FacultyWiseAllocationToolStripMenuItem})
        Me.SettingsToolStripMenuItem.Name = "SettingsToolStripMenuItem"
        Me.SettingsToolStripMenuItem.Size = New System.Drawing.Size(61, 20)
        Me.SettingsToolStripMenuItem.Text = "Settings"
        '
        'PreferenceToolStripMenuItem
        '
        Me.PreferenceToolStripMenuItem.Name = "PreferenceToolStripMenuItem"
        Me.PreferenceToolStripMenuItem.Size = New System.Drawing.Size(205, 22)
        Me.PreferenceToolStripMenuItem.Text = "Preference"
        '
        'TeachersToolStripMenuItem
        '
        Me.TeachersToolStripMenuItem.Name = "TeachersToolStripMenuItem"
        Me.TeachersToolStripMenuItem.Size = New System.Drawing.Size(205, 22)
        Me.TeachersToolStripMenuItem.Text = "Teachers"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(205, 22)
        Me.ToolStripMenuItem1.Text = "Subjects (NEW FEATURE)"
        '
        'SubjectsToolStripMenuItem
        '
        Me.SubjectsToolStripMenuItem.Name = "SubjectsToolStripMenuItem"
        Me.SubjectsToolStripMenuItem.Size = New System.Drawing.Size(205, 22)
        Me.SubjectsToolStripMenuItem.Text = "Subjects"
        '
        'SectionsToolStripMenuItem
        '
        Me.SectionsToolStripMenuItem.Name = "SectionsToolStripMenuItem"
        Me.SectionsToolStripMenuItem.Size = New System.Drawing.Size(205, 22)
        Me.SectionsToolStripMenuItem.Text = "Sections"
        '
        'ToolStripMenuItem4
        '
        Me.ToolStripMenuItem4.Name = "ToolStripMenuItem4"
        Me.ToolStripMenuItem4.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.N), System.Windows.Forms.Keys)
        Me.ToolStripMenuItem4.Size = New System.Drawing.Size(205, 22)
        Me.ToolStripMenuItem4.Text = "CSF New"
        '
        'CSFToolStripMenuItem
        '
        Me.CSFToolStripMenuItem.Name = "CSFToolStripMenuItem"
        Me.CSFToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.A), System.Windows.Forms.Keys)
        Me.CSFToolStripMenuItem.Size = New System.Drawing.Size(205, 22)
        Me.CSFToolStripMenuItem.Text = "CSF Update"
        '
        'RoomsToolStripMenuItem
        '
        Me.RoomsToolStripMenuItem.Name = "RoomsToolStripMenuItem"
        Me.RoomsToolStripMenuItem.Size = New System.Drawing.Size(205, 22)
        Me.RoomsToolStripMenuItem.Text = "Rooms"
        '
        'CourseStructureToolStripMenuItem
        '
        Me.CourseStructureToolStripMenuItem.Name = "CourseStructureToolStripMenuItem"
        Me.CourseStructureToolStripMenuItem.Size = New System.Drawing.Size(205, 22)
        Me.CourseStructureToolStripMenuItem.Text = "Course Structure"
        '
        'FacultyWiseAllocationToolStripMenuItem
        '
        Me.FacultyWiseAllocationToolStripMenuItem.Name = "FacultyWiseAllocationToolStripMenuItem"
        Me.FacultyWiseAllocationToolStripMenuItem.Size = New System.Drawing.Size(205, 22)
        Me.FacultyWiseAllocationToolStripMenuItem.Text = "FacultyWise Allocation"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AboutToolStripMenuItem, Me.CurrentSessionToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(156, 22)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'CurrentSessionToolStripMenuItem
        '
        Me.CurrentSessionToolStripMenuItem.Name = "CurrentSessionToolStripMenuItem"
        Me.CurrentSessionToolStripMenuItem.Size = New System.Drawing.Size(156, 22)
        Me.CurrentSessionToolStripMenuItem.Text = "Current Session"
        '
        'ToolsToolStripMenuItem
        '
        Me.ToolsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CheckTeacherConflictsToolStripMenuItem, Me.CheckRoomConflictsToolStripMenuItem, Me.SetDefaultRoomToolStripMenuItem, Me.SelctBatchG1ToolStripMenuItem, Me.SelectBatchG2ToolStripMenuItem, Me.RefreshToolStripMenuItem, Me.TimetablesPreviewToolStripMenuItem, Me.ColorModeToolStripMenuItem, Me.SendEmailsToolStripMenuItem})
        Me.ToolsToolStripMenuItem.Name = "ToolsToolStripMenuItem"
        Me.ToolsToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F5
        Me.ToolsToolStripMenuItem.Size = New System.Drawing.Size(47, 20)
        Me.ToolsToolStripMenuItem.Text = "Tools"
        '
        'CheckTeacherConflictsToolStripMenuItem
        '
        Me.CheckTeacherConflictsToolStripMenuItem.Name = "CheckTeacherConflictsToolStripMenuItem"
        Me.CheckTeacherConflictsToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.T), System.Windows.Forms.Keys)
        Me.CheckTeacherConflictsToolStripMenuItem.Size = New System.Drawing.Size(242, 22)
        Me.CheckTeacherConflictsToolStripMenuItem.Text = "Check Teacher Conflicts"
        '
        'CheckRoomConflictsToolStripMenuItem
        '
        Me.CheckRoomConflictsToolStripMenuItem.Name = "CheckRoomConflictsToolStripMenuItem"
        Me.CheckRoomConflictsToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.R), System.Windows.Forms.Keys)
        Me.CheckRoomConflictsToolStripMenuItem.Size = New System.Drawing.Size(242, 22)
        Me.CheckRoomConflictsToolStripMenuItem.Text = "Check Room Conflicts"
        '
        'SetDefaultRoomToolStripMenuItem
        '
        Me.SetDefaultRoomToolStripMenuItem.Name = "SetDefaultRoomToolStripMenuItem"
        Me.SetDefaultRoomToolStripMenuItem.Size = New System.Drawing.Size(242, 22)
        Me.SetDefaultRoomToolStripMenuItem.Text = "Set Default Room"
        '
        'SelctBatchG1ToolStripMenuItem
        '
        Me.SelctBatchG1ToolStripMenuItem.Name = "SelctBatchG1ToolStripMenuItem"
        Me.SelctBatchG1ToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F11
        Me.SelctBatchG1ToolStripMenuItem.Size = New System.Drawing.Size(242, 22)
        Me.SelctBatchG1ToolStripMenuItem.Text = "Select Batch-G1"
        '
        'SelectBatchG2ToolStripMenuItem
        '
        Me.SelectBatchG2ToolStripMenuItem.Name = "SelectBatchG2ToolStripMenuItem"
        Me.SelectBatchG2ToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F12
        Me.SelectBatchG2ToolStripMenuItem.Size = New System.Drawing.Size(242, 22)
        Me.SelectBatchG2ToolStripMenuItem.Text = "Select Batch-G2"
        '
        'RefreshToolStripMenuItem
        '
        Me.RefreshToolStripMenuItem.Name = "RefreshToolStripMenuItem"
        Me.RefreshToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F5
        Me.RefreshToolStripMenuItem.Size = New System.Drawing.Size(242, 22)
        Me.RefreshToolStripMenuItem.Text = "Refresh"
        '
        'TimetablesPreviewToolStripMenuItem
        '
        Me.TimetablesPreviewToolStripMenuItem.Name = "TimetablesPreviewToolStripMenuItem"
        Me.TimetablesPreviewToolStripMenuItem.Size = New System.Drawing.Size(242, 22)
        Me.TimetablesPreviewToolStripMenuItem.Text = "Timetables Preview"
        '
        'ColorModeToolStripMenuItem
        '
        Me.ColorModeToolStripMenuItem.Name = "ColorModeToolStripMenuItem"
        Me.ColorModeToolStripMenuItem.Size = New System.Drawing.Size(242, 22)
        Me.ColorModeToolStripMenuItem.Text = "ColorMode"
        '
        'SendEmailsToolStripMenuItem
        '
        Me.SendEmailsToolStripMenuItem.Name = "SendEmailsToolStripMenuItem"
        Me.SendEmailsToolStripMenuItem.Size = New System.Drawing.Size(242, 22)
        Me.SendEmailsToolStripMenuItem.Text = "Send Emails"
        '
        'ActionToolStripMenuItem
        '
        Me.ActionToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.UploadLocalPortalToolStripMenuItem, Me.UploadPDFToolStripMenuItem, Me.ConvertToSQLITEToolStripMenuItem})
        Me.ActionToolStripMenuItem.Enabled = False
        Me.ActionToolStripMenuItem.Name = "ActionToolStripMenuItem"
        Me.ActionToolStripMenuItem.Size = New System.Drawing.Size(54, 20)
        Me.ActionToolStripMenuItem.Text = "Action"
        '
        'UploadLocalPortalToolStripMenuItem
        '
        Me.UploadLocalPortalToolStripMenuItem.Enabled = False
        Me.UploadLocalPortalToolStripMenuItem.Name = "UploadLocalPortalToolStripMenuItem"
        Me.UploadLocalPortalToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F6
        Me.UploadLocalPortalToolStripMenuItem.Size = New System.Drawing.Size(196, 22)
        Me.UploadLocalPortalToolStripMenuItem.Text = "Upload Local Portal"
        '
        'UploadPDFToolStripMenuItem
        '
        Me.UploadPDFToolStripMenuItem.Enabled = False
        Me.UploadPDFToolStripMenuItem.Name = "UploadPDFToolStripMenuItem"
        Me.UploadPDFToolStripMenuItem.Size = New System.Drawing.Size(196, 22)
        Me.UploadPDFToolStripMenuItem.Text = "Upload PDF"
        '
        'ConvertToSQLITEToolStripMenuItem
        '
        Me.ConvertToSQLITEToolStripMenuItem.Name = "ConvertToSQLITEToolStripMenuItem"
        Me.ConvertToSQLITEToolStripMenuItem.Size = New System.Drawing.Size(196, 22)
        Me.ConvertToSQLITEToolStripMenuItem.Text = "Convert to SQLITE"
        '
        'ActionsToolStripMenuItem
        '
        Me.ActionsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PublishToolStripMenuItem, Me.ToolStripSeparator2, Me.ImportNWToolStripMenuItem, Me.ExportTeacherToolStripMenuItem, Me.ExportSubjectToolStripMenuItem, Me.ExportSectionsToolStripMenuItem, Me.ExportRoomsToolStripMenuItem, Me.ExportCSFToolStripMenuItem, Me.ExportActivitiesToolStripMenuItem})
        Me.ActionsToolStripMenuItem.Name = "ActionsToolStripMenuItem"
        Me.ActionsToolStripMenuItem.Size = New System.Drawing.Size(108, 20)
        Me.ActionsToolStripMenuItem.Text = "Auto-Timetables"
        '
        'PublishToolStripMenuItem
        '
        Me.PublishToolStripMenuItem.Name = "PublishToolStripMenuItem"
        Me.PublishToolStripMenuItem.Size = New System.Drawing.Size(158, 22)
        Me.PublishToolStripMenuItem.Text = "Publish"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(155, 6)
        '
        'ImportNWToolStripMenuItem
        '
        Me.ImportNWToolStripMenuItem.Name = "ImportNWToolStripMenuItem"
        Me.ImportNWToolStripMenuItem.Size = New System.Drawing.Size(158, 22)
        Me.ImportNWToolStripMenuItem.Text = "Import [NW]"
        '
        'ExportTeacherToolStripMenuItem
        '
        Me.ExportTeacherToolStripMenuItem.Name = "ExportTeacherToolStripMenuItem"
        Me.ExportTeacherToolStripMenuItem.Size = New System.Drawing.Size(158, 22)
        Me.ExportTeacherToolStripMenuItem.Text = "Export Teacher"
        '
        'ExportSubjectToolStripMenuItem
        '
        Me.ExportSubjectToolStripMenuItem.Name = "ExportSubjectToolStripMenuItem"
        Me.ExportSubjectToolStripMenuItem.Size = New System.Drawing.Size(158, 22)
        Me.ExportSubjectToolStripMenuItem.Text = "Export Subject"
        '
        'ExportSectionsToolStripMenuItem
        '
        Me.ExportSectionsToolStripMenuItem.Name = "ExportSectionsToolStripMenuItem"
        Me.ExportSectionsToolStripMenuItem.Size = New System.Drawing.Size(158, 22)
        Me.ExportSectionsToolStripMenuItem.Text = "Export Sections"
        '
        'ExportRoomsToolStripMenuItem
        '
        Me.ExportRoomsToolStripMenuItem.Name = "ExportRoomsToolStripMenuItem"
        Me.ExportRoomsToolStripMenuItem.Size = New System.Drawing.Size(158, 22)
        Me.ExportRoomsToolStripMenuItem.Text = "Export Rooms"
        '
        'ExportCSFToolStripMenuItem
        '
        Me.ExportCSFToolStripMenuItem.Name = "ExportCSFToolStripMenuItem"
        Me.ExportCSFToolStripMenuItem.Size = New System.Drawing.Size(158, 22)
        Me.ExportCSFToolStripMenuItem.Text = "Export CSF"
        '
        'ExportActivitiesToolStripMenuItem
        '
        Me.ExportActivitiesToolStripMenuItem.Name = "ExportActivitiesToolStripMenuItem"
        Me.ExportActivitiesToolStripMenuItem.Size = New System.Drawing.Size(158, 22)
        Me.ExportActivitiesToolStripMenuItem.Text = "Export Activities"
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripSeparator1, Me.cbSession, Me.cbSection, Me.ToolStripButton1, Me.ToolStripTextBox1, Me.ToolStripButton2, Me.ToolStripSeparator4, Me.ToolStripButton3})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 24)
        Me.ToolStrip1.Margin = New System.Windows.Forms.Padding(5)
        Me.ToolStrip1.MaximumSize = New System.Drawing.Size(0, 60)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Padding = New System.Windows.Forms.Padding(3)
        Me.ToolStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
        Me.ToolStrip1.Size = New System.Drawing.Size(1202, 29)
        Me.ToolStrip1.TabIndex = 15
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 23)
        '
        'cbSession
        '
        Me.cbSession.Name = "cbSession"
        Me.cbSession.Size = New System.Drawing.Size(250, 23)
        '
        'cbSection
        '
        Me.cbSection.Name = "cbSection"
        Me.cbSection.Size = New System.Drawing.Size(121, 23)
        '
        'ToolStripButton1
        '
        Me.ToolStripButton1.Image = Global.TimeTableManager.My.Resources.Resources.refresh_16xLG
        Me.ToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton1.Name = "ToolStripButton1"
        Me.ToolStripButton1.Size = New System.Drawing.Size(66, 20)
        Me.ToolStripButton1.Text = "Refresh"
        '
        'ToolStripTextBox1
        '
        Me.ToolStripTextBox1.Name = "ToolStripTextBox1"
        Me.ToolStripTextBox1.Size = New System.Drawing.Size(100, 23)
        '
        'ToolStripButton2
        '
        Me.ToolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton2.Image = Global.TimeTableManager.My.Resources.Resources.Preview_Thumbnail_
        Me.ToolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton2.Name = "ToolStripButton2"
        Me.ToolStripButton2.Size = New System.Drawing.Size(23, 20)
        Me.ToolStripButton2.Text = "ToolStripButton2"
        Me.ToolStripButton2.ToolTipText = "Timetable Preview"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(6, 23)
        '
        'ToolStripButton3
        '
        Me.ToolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton3.Image = Global.TimeTableManager.My.Resources.Resources.ComponentDiagramFile_componentdiagram_13449
        Me.ToolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton3.Name = "ToolStripButton3"
        Me.ToolStripButton3.Size = New System.Drawing.Size(23, 20)
        Me.ToolStripButton3.Text = "Multiclass View"
        Me.ToolStripButton3.ToolTipText = "Multiclass View"
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripLabel1, Me.tsLTPLabel})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 621)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(1202, 22)
        Me.StatusStrip1.TabIndex = 17
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripLabel1
        '
        Me.ToolStripLabel1.Name = "ToolStripLabel1"
        Me.ToolStripLabel1.Size = New System.Drawing.Size(140, 17)
        Me.ToolStripLabel1.Text = "Current Room selected :: "
        '
        'tsLTPLabel
        '
        Me.tsLTPLabel.Name = "tsLTPLabel"
        Me.tsLTPLabel.Size = New System.Drawing.Size(46, 17)
        Me.tsLTPLabel.Text = "Lecture"
        '
        'rSOE
        '
        Me.rSOE.AutoSize = True
        Me.rSOE.Location = New System.Drawing.Point(13, 16)
        Me.rSOE.Name = "rSOE"
        Me.rSOE.Size = New System.Drawing.Size(47, 17)
        Me.rSOE.TabIndex = 19
        Me.rSOE.Text = "SOE"
        Me.rSOE.UseVisualStyleBackColor = True
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.SplitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer1.Location = New System.Drawing.Point(902, 53)
        Me.SplitContainer1.Name = "SplitContainer1"
        Me.SplitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.rSOHSS)
        Me.SplitContainer1.Panel1.Controls.Add(Me.rSOLJ)
        Me.SplitContainer1.Panel1.Controls.Add(Me.rSOBSC)
        Me.SplitContainer1.Panel1.Controls.Add(Me.rAll)
        Me.SplitContainer1.Panel1.Controls.Add(Me.rSOVSAS)
        Me.SplitContainer1.Panel1.Controls.Add(Me.rSOM)
        Me.SplitContainer1.Panel1.Controls.Add(Me.rSOBT)
        Me.SplitContainer1.Panel1.Controls.Add(Me.rICT)
        Me.SplitContainer1.Panel1.Controls.Add(Me.rSOE)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.DataGridView1)
        Me.SplitContainer1.Size = New System.Drawing.Size(288, 564)
        Me.SplitContainer1.SplitterDistance = 73
        Me.SplitContainer1.TabIndex = 20
        '
        'rSOHSS
        '
        Me.rSOHSS.AutoSize = True
        Me.rSOHSS.Location = New System.Drawing.Point(204, 39)
        Me.rSOHSS.Name = "rSOHSS"
        Me.rSOHSS.Size = New System.Drawing.Size(62, 17)
        Me.rSOHSS.TabIndex = 27
        Me.rSOHSS.Text = "SOHSS"
        Me.rSOHSS.UseVisualStyleBackColor = True
        '
        'rSOLJ
        '
        Me.rSOLJ.AutoSize = True
        Me.rSOLJ.Location = New System.Drawing.Point(154, 39)
        Me.rSOLJ.Name = "rSOLJ"
        Me.rSOLJ.Size = New System.Drawing.Size(51, 17)
        Me.rSOLJ.TabIndex = 26
        Me.rSOLJ.Text = "SOLJ"
        Me.rSOLJ.UseVisualStyleBackColor = True
        '
        'rSOBSC
        '
        Me.rSOBSC.AutoSize = True
        Me.rSOBSC.Location = New System.Drawing.Point(87, 39)
        Me.rSOBSC.Name = "rSOBSC"
        Me.rSOBSC.Size = New System.Drawing.Size(61, 17)
        Me.rSOBSC.TabIndex = 25
        Me.rSOBSC.Text = "SOBSC"
        Me.rSOBSC.UseVisualStyleBackColor = True
        '
        'rAll
        '
        Me.rAll.AutoSize = True
        Me.rAll.Checked = True
        Me.rAll.Location = New System.Drawing.Point(229, 16)
        Me.rAll.Name = "rAll"
        Me.rAll.Size = New System.Drawing.Size(36, 17)
        Me.rAll.TabIndex = 24
        Me.rAll.TabStop = True
        Me.rAll.Text = "All"
        Me.rAll.UseVisualStyleBackColor = True
        '
        'rSOVSAS
        '
        Me.rSOVSAS.AutoSize = True
        Me.rSOVSAS.Location = New System.Drawing.Point(13, 39)
        Me.rSOVSAS.Name = "rSOVSAS"
        Me.rSOVSAS.Size = New System.Drawing.Size(68, 17)
        Me.rSOVSAS.TabIndex = 23
        Me.rSOVSAS.Text = "SOVSAS"
        Me.rSOVSAS.UseVisualStyleBackColor = True
        '
        'rSOM
        '
        Me.rSOM.AutoSize = True
        Me.rSOM.Location = New System.Drawing.Point(176, 16)
        Me.rSOM.Name = "rSOM"
        Me.rSOM.Size = New System.Drawing.Size(49, 17)
        Me.rSOM.TabIndex = 22
        Me.rSOM.Text = "SOM"
        Me.rSOM.UseVisualStyleBackColor = True
        '
        'rSOBT
        '
        Me.rSOBT.AutoSize = True
        Me.rSOBT.Location = New System.Drawing.Point(122, 16)
        Me.rSOBT.Name = "rSOBT"
        Me.rSOBT.Size = New System.Drawing.Size(54, 17)
        Me.rSOBT.TabIndex = 21
        Me.rSOBT.Text = "SOBT"
        Me.rSOBT.UseVisualStyleBackColor = True
        '
        'rICT
        '
        Me.rICT.AutoSize = True
        Me.rICT.Location = New System.Drawing.Point(66, 16)
        Me.rICT.Name = "rICT"
        Me.rICT.Size = New System.Drawing.Size(57, 17)
        Me.rICT.TabIndex = 20
        Me.rICT.Text = "SOICT"
        Me.rICT.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToOrderColumns = True
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DataGridView1.Location = New System.Drawing.Point(0, 0)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(288, 487)
        Me.DataGridView1.TabIndex = 6
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'FillByToolStrip1
        '
        Me.FillByToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SchoolToolStripLabel, Me.SchoolToolStripTextBox, Me.FillByToolStripButton1})
        Me.FillByToolStrip1.Location = New System.Drawing.Point(0, 49)
        Me.FillByToolStrip1.Name = "FillByToolStrip1"
        Me.FillByToolStrip1.Size = New System.Drawing.Size(1202, 25)
        Me.FillByToolStrip1.TabIndex = 22
        Me.FillByToolStrip1.Text = "FillByToolStrip1"
        Me.FillByToolStrip1.Visible = False
        '
        'SchoolToolStripLabel
        '
        Me.SchoolToolStripLabel.Name = "SchoolToolStripLabel"
        Me.SchoolToolStripLabel.Size = New System.Drawing.Size(45, 22)
        Me.SchoolToolStripLabel.Text = "school:"
        '
        'SchoolToolStripTextBox
        '
        Me.SchoolToolStripTextBox.Name = "SchoolToolStripTextBox"
        Me.SchoolToolStripTextBox.Size = New System.Drawing.Size(100, 25)
        '
        'FillByToolStripButton1
        '
        Me.FillByToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.FillByToolStripButton1.Name = "FillByToolStripButton1"
        Me.FillByToolStripButton1.Size = New System.Drawing.Size(39, 22)
        Me.FillByToolStripButton1.Text = "FillBy"
        '
        'userinfo
        '
        Me.userinfo.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.userinfo.AutoSize = True
        Me.userinfo.Location = New System.Drawing.Point(1151, 6)
        Me.userinfo.Name = "userinfo"
        Me.userinfo.Size = New System.Drawing.Size(16, 13)
        Me.userinfo.TabIndex = 23
        Me.userinfo.Text = "..."
        '
        'MSectionBindingSource
        '
        Me.MSectionBindingSource.DataMember = "Section"
        Me.MSectionBindingSource.DataSource = Me.ECollegeDataSet
        Me.MSectionBindingSource.Sort = "name"
        '
        'ECollegeDataSet
        '
        Me.ECollegeDataSet.DataSetName = "eCollegeDataSet"
        Me.ECollegeDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'bsProgram
        '
        Me.bsProgram.DataMember = "Program"
        Me.bsProgram.DataSource = Me.ECollegeDataSet
        '
        'ECollegeDataSet1
        '
        Me.ECollegeDataSet1.DataSetName = "eCollegeDataSet1"
        Me.ECollegeDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'V_TimeTableTableAdapter
        '
        Me.V_TimeTableTableAdapter.ClearBeforeFill = True
        '
        'bsSection
        '
        Me.bsSection.DataMember = "Section"
        Me.bsSection.DataSource = Me.ECollegeDataSet
        '
        'SectionTableAdapter
        '
        Me.SectionTableAdapter.ClearBeforeFill = True
        '
        'ProgramTableAdapter1
        '
        Me.ProgramTableAdapter1.ClearBeforeFill = True
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1202, 643)
        Me.Controls.Add(Me.userinfo)
        Me.Controls.Add(Me.FillByToolStrip1)
        Me.Controls.Add(Me.SplitContainer1)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.RadioButton2)
        Me.Controls.Add(Me.RadioButton1)
        Me.Controls.Add(Me.BatchF)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.CSFList)
        Me.Controls.Add(Me.FillByToolStrip)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "frmMain"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.ContextMenuStrip1.ResumeLayout(False)
        CType(Me.CSFList, System.ComponentModel.ISupportInitialize).EndInit()
        Me.FillByToolStrip.ResumeLayout(False)
        Me.FillByToolStrip.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel1.PerformLayout()
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.ResumeLayout(False)
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.FillByToolStrip1.ResumeLayout(False)
        Me.FillByToolStrip1.PerformLayout()
        CType(Me.VTimeTableBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MSectionBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ECollegeDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsProgram, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ECollegeDataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsSection, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents TextBox41 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox42 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox43 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox44 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox45 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox46 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox47 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox48 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox33 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox34 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox35 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox36 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox37 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox38 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox39 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox40 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox25 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox26 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox27 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox28 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox29 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox30 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox31 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox32 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox17 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox18 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox19 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox20 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox21 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox22 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox23 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox24 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox9 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox10 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox11 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox12 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox13 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox14 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox15 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox16 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox8 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox7 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox6 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents ECollegeDataSet As TimeTableManager.eCollegeDataSet
    Friend WithEvents MSectionBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents M_SectionTableAdapter As TimeTableManager.eCollegeDataSetTableAdapters.M_SectionTableAdapter
    Friend WithEvents ECollegeDataSet1 As TimeTableManager.eCollegeDataSet
    Friend WithEvents bsProgram As System.Windows.Forms.BindingSource
    'Friend WithEvents M_SessionTableAdapter As TimeTableManager.eCollegeDataSetTableAdapters.M_SessionTableAdapter
    Friend WithEvents VTimeTableBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents V_TimeTableTableAdapter As TimeTableManager.eCollegeDataSetTableAdapters.V_TimeTableTableAdapter
    Friend WithEvents CSFList As System.Windows.Forms.DataGridView
    Friend WithEvents FillByToolStrip As System.Windows.Forms.ToolStrip
    Friend WithEvents FillByToolStripButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents BatchF As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton1 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton2 As System.Windows.Forms.RadioButton
    Friend WithEvents ColorDialog1 As System.Windows.Forms.ColorDialog
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents SettingsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PreferenceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents cbSession As System.Windows.Forms.ToolStripComboBox
    Friend WithEvents cbSection As System.Windows.Forms.ToolStripComboBox
    Friend WithEvents ToolsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CheckTeacherConflictsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CheckRoomConflictsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SetDefaultRoomToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents ToolStripLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents TeachersToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SubjectsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SectionsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents bsSection As System.Windows.Forms.BindingSource
    Friend WithEvents SectionTableAdapter As TimeTableManager.eCollegeDataSetTableAdapters.SectionTableAdapter
    Friend WithEvents CSFToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RoomsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripButton1 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripTextBox1 As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents SelctBatchG1ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SelectBatchG2ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RefreshToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TimetablesPreviewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ActionsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PublishToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ImportNWToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExportTeacherToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExportSubjectToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExportSectionsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExportRoomsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExportCSFToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ProgramTableAdapter1 As TimeTableManager.eCollegeDataSetTableAdapters.ProgramTableAdapter
    Friend WithEvents ExportActivitiesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CourseStructureToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents rSOE As System.Windows.Forms.RadioButton
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents rSOM As System.Windows.Forms.RadioButton
    Friend WithEvents rSOBT As System.Windows.Forms.RadioButton
    Friend WithEvents rICT As System.Windows.Forms.RadioButton
    Friend WithEvents rAll As System.Windows.Forms.RadioButton
    Friend WithEvents rSOVSAS As System.Windows.Forms.RadioButton
    Friend WithEvents tsLTPLabel As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ContextMenuStrip1 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents InsertToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DeleteToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CopyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PasteToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TextBox49 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox50 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox51 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox52 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox53 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox54 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox55 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox56 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox57 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox58 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox59 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox60 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox61 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox62 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox63 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox70 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox69 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox68 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox67 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox66 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox65 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox64 As System.Windows.Forms.TextBox
    Friend WithEvents ToolStripButton2 As System.Windows.Forms.ToolStripButton
    Friend WithEvents CopyToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PasteToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SwapToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents DeleteToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripButton3 As System.Windows.Forms.ToolStripButton
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents FillByToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents SchoolToolStripLabel As System.Windows.Forms.ToolStripLabel
    Friend WithEvents SchoolToolStripTextBox As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents FillByToolStripButton1 As System.Windows.Forms.ToolStripButton
    Friend WithEvents userinfo As System.Windows.Forms.Label
    Friend WithEvents ToolStripMenuItem4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents rSOHSS As System.Windows.Forms.RadioButton
    Friend WithEvents rSOLJ As System.Windows.Forms.RadioButton
    Friend WithEvents rSOBSC As System.Windows.Forms.RadioButton
    Friend WithEvents FacultyWiseAllocationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TextBox77 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox76 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox75 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox74 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox73 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox72 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox71 As System.Windows.Forms.TextBox
    Friend WithEvents ColorModeToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ActionToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents UploadLocalPortalToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents UploadPDFToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator4 As ToolStripSeparator
    Friend WithEvents QuickInsertToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ConvertToSQLITEToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents CurrentSessionToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SendEmailsToolStripMenuItem As ToolStripMenuItem
End Class
