﻿Public Module GlobalVariables
    Public ApplicationName As String = "Time 17"
End Module